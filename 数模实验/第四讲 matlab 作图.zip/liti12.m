[x,y,z]=peaks(30);
      surf(x,y,z)
      %shading  flat
