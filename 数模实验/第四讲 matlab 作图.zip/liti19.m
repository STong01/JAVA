        [x,y,z]=peaks(30);
        waterfall(x,y,z)
        xlabel('x-axis')
        ylabel('y-axis')
        zlabel('z-axis')
        title('����peaks��waterfallͼ'); 