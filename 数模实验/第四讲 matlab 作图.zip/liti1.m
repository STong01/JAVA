x=linspace(0,2*pi,30);
plot(x,sin(x),'r',x,cos(x),'go')
