       a=linspace(0,2*pi),                         
       b=sin(2*a).*cos(2*a);
        polar(a,b,'g')
        title('Polar plot of sin(2*theta).*cos(2*theta)');