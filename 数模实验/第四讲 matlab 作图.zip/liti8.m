t=0:pi/50:10*pi;
      plot3(sin(t),cos(t),t)
            rotate3d