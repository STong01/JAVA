x=rand(1,5)
y=rand(1,5)
z=rand(1,5)
scatter3(x,y,z)