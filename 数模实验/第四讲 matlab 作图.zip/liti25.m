ezplot('cos(x)',[0,pi])
