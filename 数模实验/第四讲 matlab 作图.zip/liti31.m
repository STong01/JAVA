income=[3.2 4.1 5.0 5.6];
outgo=[2.5 4.0 3.35 4.9];
subplot(2,1,1);plot(income)
subplot(2,1,2);plot(outgo)