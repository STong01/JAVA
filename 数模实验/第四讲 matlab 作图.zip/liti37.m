x=logspace(-1,2);
loglog(x,exp(x),'-s')
grid on
