x=0:.1:10;
semilogy(x,10.^x)
