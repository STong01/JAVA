x=linspace(0,2*pi,30);
z=cos(x);
y=sin(x);
plot(x,z,:)
hold on
plot(x,y)
 zoom  on
 zoom off