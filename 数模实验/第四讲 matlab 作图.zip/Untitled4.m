x=-2*pi:0.1:2*pi;
y1=tanh(x);
y2=sin(x);
y3=cos(x)
plot(x,y1,x,y2,x,y3)