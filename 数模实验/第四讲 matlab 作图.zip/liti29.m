x=rand(1,5)
y=rand(1,5)
scatter(x,y)