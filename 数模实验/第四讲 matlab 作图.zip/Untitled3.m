
fplot(fh,[-20 20])